﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace CraftCenter.OregonState.Edu.Tests
{
    public static class Utilities
    {
        public static ILoggerFactory GetLoggerFactory()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddLogging(x => x.AddConsole());
            var serviceProvider = serviceCollection.BuildServiceProvider();
            return serviceProvider.GetService<ILoggerFactory>();
        }
    }
}