﻿using CraftCenter.OregonState.Edu.Services;
using CraftCenter.OregonState.Edu.Services.Requests;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.Tests.Service
{
    [TestClass]
    [TestCategory("Integration")]  //connect to actual sql server database
    public class UserServiceIntegrationTests : BaseTests
    {

        [TestMethod]
        public async Task CanSaveUser()
        {
            await using var serviceContext = CreateSqlServerDbContext(false, true);
            
            var service = new UserService(serviceContext);

            var request = new NewUserRequest
            {
                Name = "John Snow",
                EmailAddress = "jsnow@thewall.com",
                Issuer = "George C. Martin",
                ClaimIdentifier = "badass",
                UserRole = "King"
            };

            var result = await service.SaveUserAsync(request);

            await using var verifierContext = CreateSqlServerDbContext(false, true);
            var verifiedUser = await verifierContext.Users.SingleOrDefaultAsync(x => x.Id == result.Id);
            verifiedUser.Should().NotBeNull();
            verifiedUser.Id.Should().BeGreaterThan(0);
            verifiedUser.ClaimIdentifier.Should().Be(request.ClaimIdentifier);
            verifiedUser.EmailAddress.Should().Be(request.EmailAddress);
            verifiedUser.Issuer.Should().Be(request.Issuer);
            verifiedUser.Name.Should().Be(request.Name);
            verifiedUser.Role.Should().Be(request.UserRole);

            await using var cleanupContext = CreateSqlServerDbContext(false, true);
            cleanupContext.Remove(result);
            await cleanupContext.SaveChangesAsync();
        }
    }
}