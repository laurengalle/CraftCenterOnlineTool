﻿using CraftCenter.OregonState.Edu.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CraftCenter.OregonState.Edu.Tests.Service
{
    [TestClass]
    [TestCategory("Unit")]
    public class ServiceMappingTests
    {
        [TestMethod]
        public void CanMapFromService()
        {
            //Enforce mappings are set up in a complete manner
            ServiceMapper.Mapper.ConfigurationProvider.AssertConfigurationIsValid();
        }
    }
}