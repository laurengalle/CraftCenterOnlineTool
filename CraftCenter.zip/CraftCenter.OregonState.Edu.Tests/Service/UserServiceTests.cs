using CraftCenter.OregonState.Edu.DataAccessClass;
using CraftCenter.OregonState.Edu.Services;
using CraftCenter.OregonState.Edu.Services.Requests;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using System;
using System.Threading.Tasks;
using CraftCenter.OregonState.Edu.DataAccess;

namespace CraftCenter.OregonState.Edu.Tests.Service
{
    [TestClass]
    [TestCategory("Unit")]
    public class UserServiceTests : BaseTests
    {
        [TestMethod]
        public async Task CanSaveUserAsyncMockingExample()
        {
            var dbContext = Substitute.For<IDatabaseContext>();

            var service = new UserService(dbContext);

            var request = new NewUserRequest
            {
                ClaimIdentifier = "some claim id",
                EmailAddress = "a@b.c",
                Issuer = "froogle",
                Name = "Jon Snow",
                UserRole = "King"
            };

            await service.Invoking(x => x.SaveUserAsync(request))
                .Should()
                .NotThrowAsync();

            await dbContext.Users.Received(1).AddAsync(Arg.Is<User>(x =>
                x.ClaimIdentifier == request.ClaimIdentifier
                && x.EmailAddress == request.EmailAddress
                && x.Name == request.Name
                && x.Role == request.UserRole));

            await dbContext.Received(1).SaveChangesAsync();
        }

        [TestMethod]
        public async Task CanSaveUserAsyncInMemoryDatabaseExample()
        {
            var dbName = Guid.NewGuid().ToString();

            var serviceContext = CreateInMemoryDbContext(dbName);
            var service = new UserService(serviceContext);

            var request = new NewUserRequest
            {
                Name = "John Snow",
                EmailAddress = "jsnow@thewall.com",
                Issuer = "George C. Martin",
                ClaimIdentifier = "badass",
                UserRole = "King"
            };
            
            var result = await service.SaveUserAsync(request);

            var verifierContext = CreateInMemoryDbContext(dbName);
            var users = await verifierContext.Users.ToListAsync();

            var verifiedUser = await verifierContext.Users.SingleOrDefaultAsync(x => x.Id == result.Id);
            verifiedUser.Should().NotBeNull();
            verifiedUser.Id.Should().BeGreaterThan(0);
            verifiedUser.ClaimIdentifier.Should().Be(request.ClaimIdentifier);
            verifiedUser.EmailAddress.Should().Be(request.EmailAddress);
            verifiedUser.Issuer.Should().Be(request.Issuer);
            verifiedUser.Name.Should().Be(request.Name);
            verifiedUser.Role.Should().Be(request.UserRole);
        }
    }
}
