﻿using System.Linq;
using CraftCenter.OregonState.Edu.Domain.Model;

namespace CraftCenter.OregonState.Edu.Repository
{
    public interface IClassRegistrationRepository
    {
        IQueryable<string> GetAllCourseCategories();

        IQueryable<Course> GetCoursesByCategory(string category);

        IQueryable<Course> GetCourse(int courseId);
    }
}