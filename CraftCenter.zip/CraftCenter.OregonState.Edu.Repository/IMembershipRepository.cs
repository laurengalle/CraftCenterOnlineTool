﻿using CraftCenter.OregonState.Edu.Domain.Model;

namespace CraftCenter.OregonState.Edu.Repository
{
    public interface IMembershipRepository
    {
        void CreateMembership(Membership membership);
    }
}