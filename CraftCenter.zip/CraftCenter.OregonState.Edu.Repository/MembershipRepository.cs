﻿using CraftCenter.OregonState.Edu.DataAccess;
using CraftCenter.OregonState.Edu.Domain.Model;

namespace CraftCenter.OregonState.Edu.Repository
{
    public class MembershipRepository : IMembershipRepository
    {
        private readonly IDatabaseContext dbContext;

        public MembershipRepository(IDatabaseContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public void CreateMembership(Membership membership)
        {
            dbContext.Memberships.Add(membership);
        }
    }
}
