﻿using System.Linq;
using CraftCenter.OregonState.Edu.DataAccess;
using CraftCenter.OregonState.Edu.Domain.Model;
using Microsoft.EntityFrameworkCore;

namespace CraftCenter.OregonState.Edu.Repository
{
    public class ClassRegistrationRepository : IClassRegistrationRepository
    {
        private readonly IDatabaseContext dbContext;

        public ClassRegistrationRepository(IDatabaseContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public IQueryable<string> GetAllCourseCategories()
        {
            return dbContext.Courses
                .Select(x => x.CategoryName)
                .Distinct();
        }

        public IQueryable<Course> GetCoursesByCategory(string category)
        {
            return dbContext.Courses
                .Where(x => x.CategoryName == category);
        }

        public IQueryable<Course> GetCourse(int courseId)
        {
            return dbContext.Courses
                .Include(x => x.Sections)
                .Where(x => x.Id == courseId);
        }
    }
}