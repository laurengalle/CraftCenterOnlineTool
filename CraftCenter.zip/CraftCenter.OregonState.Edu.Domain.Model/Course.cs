﻿using System.Collections.Generic;

namespace CraftCenter.OregonState.Edu.Domain.Model
{
    public class Course
    {
        public int Id { get; set; }

        public string CategoryName { get; set; }

        public string Name { get; set; }

        public int Fee { get; set; }

        public int LengthInMinutes { get; set; }

        public List<Section> Sections { get; set; }
    }
}