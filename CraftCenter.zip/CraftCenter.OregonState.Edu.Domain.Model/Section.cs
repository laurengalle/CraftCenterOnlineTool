﻿namespace CraftCenter.OregonState.Edu.Domain.Model
{
    public class Section
    {
        public int Id { get; set; }

        public int CourseId { get; set; }

        public string Name { get; set; }

        public string Instructor { get; set; }
    }
}
