﻿namespace CraftCenter.OregonState.Edu.DataAccessClass
{
    public class User
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Issuer { get; set; }

        public string EmailAddress { get; set; }

        public string Role { get; set; }

        public string ClaimIdentifier { get; set; }
    }
}
