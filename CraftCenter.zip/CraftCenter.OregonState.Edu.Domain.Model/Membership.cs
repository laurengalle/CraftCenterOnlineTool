﻿namespace CraftCenter.OregonState.Edu.Domain.Model
{
    public class Membership
    {
        public int Id { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }
    }
}