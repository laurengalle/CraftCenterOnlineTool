﻿using System.Collections.Generic;

namespace CraftCenter.OregonState.Edu.Services.Responses
{
    public class GetAllCourseCategoriesResponse
    {
        public List<string> Categories { get; set; } = new List<string>();
    }
}
