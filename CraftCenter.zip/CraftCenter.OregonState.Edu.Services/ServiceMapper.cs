﻿using AutoMapper;
using CraftCenter.OregonState.Edu.Domain.Model;
using CraftCenter.OregonState.Edu.Services.Common;
using CraftCenter.OregonState.Edu.Services.Responses;
using System.Collections.Generic;
using CraftCenter.OregonState.Edu.Services.Requests;

namespace CraftCenter.OregonState.Edu.Services
{
    public static class ServiceMapper
    {
        static ServiceMapper()
        {
            var config = new MapperConfiguration(cfg =>
            {
                SetupDomainModelToServiceLayer(cfg);

                SetupServiceLayerToDomainModel(cfg);
            });

            Mapper = config.CreateMapper();
        }

        public static IMapper Mapper { get; private set; }

        private static void SetupDomainModelToServiceLayer(IMapperConfigurationExpression cfg)
        {
            //Domain to DTO mapping
            cfg.CreateMap<Course, CourseDto>();

            cfg.CreateMap<Section, SectionDto>();

            //Response mapping
            cfg.CreateMap<List<Course>, GetCoursesResponse>()
                .ForMember(response => response.Courses, opt => opt.MapFrom(c => c))
                .ForMember(response => response.CategoryName, opt => opt.Ignore());

            cfg.CreateMap<List<string>, GetAllCourseCategoriesResponse>()
                .ForMember(response => response.Categories, opt => opt.MapFrom(x => x));

            cfg.CreateMap<Course, GetScheduleResponse>()
                .ForMember(response => response.Sections, opt => opt.MapFrom(s => s.Sections))
                .ForMember(response => response.CourseName, opt => opt.MapFrom(c => c.Name));
        }

        private static void SetupServiceLayerToDomainModel(IMapperConfigurationExpression cfg)
        {
            cfg.CreateMap<NewMembershipRequest, Membership>();
        }
    }
}
