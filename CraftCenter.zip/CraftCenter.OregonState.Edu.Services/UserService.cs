﻿using System.Collections.Generic;
using CraftCenter.OregonState.Edu.DataAccessClass;
using CraftCenter.OregonState.Edu.Services.Requests;
using System.Threading.Tasks;
using CraftCenter.OregonState.Edu.DataAccess;
using Microsoft.EntityFrameworkCore;

namespace CraftCenter.OregonState.Edu.Services
{
    public class UserService : IUserService
    {
        private readonly IDatabaseContext dbContext;

        public UserService(IDatabaseContext dbContext)
        {
            this.dbContext = dbContext;
        }
        
        public async Task<User> SaveUserAsync(NewUserRequest request)
        {
            var user = new User
            {
                EmailAddress = request.EmailAddress,
                Issuer = request.Issuer,
                Name = request.Name,
                Role = request.UserRole,
                ClaimIdentifier = request.ClaimIdentifier
            };

            await dbContext.Users.AddAsync(user);

            await dbContext.SaveChangesAsync();

            return user;
        }

        public async Task<List<User>> GetUsers()
        {
            return await dbContext.Users.ToListAsync();
        }
    }
}
