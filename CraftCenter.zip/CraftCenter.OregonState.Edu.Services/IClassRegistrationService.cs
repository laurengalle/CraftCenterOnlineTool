﻿using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.Services
{
    using Responses;

    public interface IClassRegistrationService
    {
        Task<GetAllCourseCategoriesResponse> GetAllCourseCategories();

        Task<GetCoursesResponse> GetCoursesByCategory(string category);

        Task<GetScheduleResponse> GetSchedule(int courseId);
    }
}
