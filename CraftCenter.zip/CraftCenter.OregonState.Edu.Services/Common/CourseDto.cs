﻿namespace CraftCenter.OregonState.Edu.Services.Common
{
    public class CourseDto
    {
        public int Id { get; set; }

        public string CategoryName { get; set; }

        public string Name { get; set; }

        public string Fee { get; set; }

        public int LengthInMinutes { get; set; }
    }
}