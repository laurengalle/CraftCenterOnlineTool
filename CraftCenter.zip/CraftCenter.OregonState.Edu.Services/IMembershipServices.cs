﻿using System.Threading.Tasks;
using CraftCenter.OregonState.Edu.Services.Requests;

namespace CraftCenter.OregonState.Edu.Services
{
    public interface IMembershipServices
    {
        Task CreateMembership(NewMembershipRequest request);
    }
}