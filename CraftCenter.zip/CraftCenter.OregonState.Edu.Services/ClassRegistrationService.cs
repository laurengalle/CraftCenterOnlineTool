﻿using CraftCenter.OregonState.Edu.DataAccess;
using CraftCenter.OregonState.Edu.Repository;
using CraftCenter.OregonState.Edu.Services.Responses;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using static CraftCenter.OregonState.Edu.Services.ServiceMapper;
using static CraftCenter.OregonState.Edu.Domain.Model.Exceptions.ExceptionUtility;

namespace CraftCenter.OregonState.Edu.Services
{
    public class ClassRegistrationService : IClassRegistrationService
    {
        private readonly IDbUnitOfWork unitOfWork;
        private readonly IClassRegistrationRepository repository;

        public ClassRegistrationService(IDbUnitOfWork unitOfWork, IClassRegistrationRepository repository)
        {
            this.unitOfWork = unitOfWork;
            this.repository = repository;
        }

        public async Task<GetAllCourseCategoriesResponse> GetAllCourseCategories()
        {
            var categories = await repository.GetAllCourseCategories().ToListAsync();
                
            return Mapper.Map<GetAllCourseCategoriesResponse>(categories);
        }

        public async Task<GetCoursesResponse> GetCoursesByCategory(string category)
        {
            var courses = await repository.GetCoursesByCategory(category)
                .ToListAsync();

            var response = Mapper.Map<GetCoursesResponse>(courses);
            response.CategoryName = category;

            return response;
        }

        public async Task<GetScheduleResponse> GetSchedule(int courseId)
        {
            var course = await repository.GetCourse(courseId)
                .SingleOrDefaultAsync();
            
            ThrowDomainObjectNotFoundException(course, courseId);

            return Mapper.Map<GetScheduleResponse>(course);
        }
    }
}