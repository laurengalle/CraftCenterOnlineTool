﻿namespace CraftCenter.OregonState.Edu.Services.Requests
{
    public class NewUserRequest
    {
        public string Name { get; set; }

        public string ClaimIdentifier { get; set; }

        public string Issuer { get; set; }

        public string EmailAddress { get; set; }

        public string UserRole { get; set; }

    }
}