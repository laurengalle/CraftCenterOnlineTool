﻿namespace CraftCenter.OregonState.Edu.Services.Requests
{
    public class NewMembershipRequest
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }
    }
}