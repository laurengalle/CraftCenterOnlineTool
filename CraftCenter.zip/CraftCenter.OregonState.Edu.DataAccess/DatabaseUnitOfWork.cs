﻿namespace CraftCenter.OregonState.Edu.DataAccess
{
    using System.Threading.Tasks;

    public class DatabaseUnitOfWork : IDbUnitOfWork
    {
        public DatabaseUnitOfWork(IDatabaseContext databaseContext)
        {
            Context = databaseContext;
        }

        public IDatabaseContext Context { get; }

        public int Save()
        {
            return Context.SaveChanges();
        }

        public async Task<int> SaveAsync()
        {
            return await Context.SaveChangesAsync();
        }
    }
}
