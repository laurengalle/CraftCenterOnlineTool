﻿using CraftCenter.OregonState.Edu.DataAccess.ModelBuilderExtensions;
using CraftCenter.OregonState.Edu.DataAccessClass;
using CraftCenter.OregonState.Edu.Domain.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace CraftCenter.OregonState.Edu.DataAccess
{
    /// <summary>
    /// See https://docs.microsoft.com/en-us/ef/core/cli/powershell#common-parameters for running the migration commands available in the Package Manager Console
    /// </summary>
    public class DatabaseContext : DbContext, IDatabaseContext
    {
        public static readonly ILoggerFactory LoggerFactory = Microsoft.Extensions.Logging.LoggerFactory.Create(b =>
        {
            b.AddConsole();
            b.AddFilter(DbLoggerCategory.Migrations.Name, LogLevel.Debug);
        });
        private readonly ISettingsProvider settingsProvider;
        // This constructor is need when running the migration commands from the Package Manager Console within Visual Studio.
        public DatabaseContext()
        {
        }

        public DatabaseContext(DbContextOptions options, ISettingsProvider settingsProvider)
            : base(options)
        {
            this.settingsProvider = settingsProvider;
        }

        //IDatabaseContext
        public DbSet<User> Users { get; set; }

        public DbSet<Course> Courses { get; set; }

        public DbSet<Section> Sections { get; set; }

        public DbSet<Membership> Memberships { get; set; }

        //overrides to the base class for setting up the database table/relations using ef core's fluent style configuration
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.BuildTableRelations();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (optionsBuilder.IsConfigured) return;

            var cnString = settingsProvider?.DbConnectionString;

#if DEBUG
            //Comment out this line if a connection to a database other that your local db is needed.
            //Otherwise during development efforts, this defaults to your local database.   
            cnString = @"Data Source=.;Initial Catalog=MVC-CraftCenter;Trusted_Connection=true";
            optionsBuilder.EnableSensitiveDataLogging();
#endif
            optionsBuilder.UseSqlServer(cnString,
                x => x.MigrationsHistoryTable("MigrationHistory"));

            optionsBuilder.UseLoggerFactory(LoggerFactory);
        }
    }
}
