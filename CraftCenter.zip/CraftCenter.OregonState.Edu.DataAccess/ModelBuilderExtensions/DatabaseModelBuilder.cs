﻿using System.Collections.Generic;
using CraftCenter.OregonState.Edu.DataAccessClass;
using CraftCenter.OregonState.Edu.Domain.Model;
using Microsoft.EntityFrameworkCore;

namespace CraftCenter.OregonState.Edu.DataAccess.ModelBuilderExtensions
{
    //todo:  create Repository layer with unit of work...
    public static class DatabaseModelBuilder
    {
        public static void BuildTableRelations(this ModelBuilder modelBuilder)
        {
            BuildUserDataTable(modelBuilder);
            BuildCourseTable(modelBuilder);
            BuildSectionTable(modelBuilder);
            BuildMembershipTable(modelBuilder);
        }

        private static void BuildMembershipTable(ModelBuilder modelBuilder)
        {
            var entity = modelBuilder.Entity<Membership>();

            entity
                .HasKey(m => m.Id);
        }

        private static void BuildUserDataTable(ModelBuilder modelBuilder)
        {
            var entity = modelBuilder.Entity<User>();

            entity
                .HasKey(u => u.Id);
        }

        private static void BuildCourseTable(ModelBuilder modelBuilder)
        {
            var entity = modelBuilder.Entity<Course>();

            entity
                .HasKey(c => c.Id);

#if DEBUG
            //temporary data used during development efforts that should be removed before going to production.  
            entity.HasData(GetCourseData());
#endif
        }

        private static void BuildSectionTable(ModelBuilder modelBuilder)
        {
            var entity = modelBuilder.Entity<Section>();

            entity
                .HasKey(s => s.Id);

            entity
                .HasOne<Course>()
                .WithMany(x => x.Sections)
                .HasForeignKey(x => x.CourseId);

#if DEBUG
            entity.HasData(GetSectionData());
#endif
        }

        private static IEnumerable<Course> GetCourseData()
        {
            return new List<Course>
            {
                new Course
                {
                    Id = 1,
                    CategoryName = "Ceramics",
                    Name = "chicken",
                    Fee = 0,
                    LengthInMinutes = 30
                },
                new Course
                {
                    Id = 2,
                    CategoryName = "FiberArts",
                    Name = "duck",
                    Fee = 120,
                    LengthInMinutes = 75
                }
            };
        }

        private static IEnumerable<Section> GetSectionData()
        {
            return new List<Section>
            {
                new Section {Id = 1, CourseId = 1, Name = "chicken", Instructor = "Foster Farm"},
                new Section {Id = 2, CourseId = 1, Name = "duck", Instructor = "Daffy Duck"},
                new Section {Id = 3, CourseId = 2, Name = "Wool Production", Instructor = "Sheep Pig"},
                new Section {Id = 4, CourseId = 2, Name = "Cotton Production", Instructor = "Farmer John"}
            };
        }
    }
}