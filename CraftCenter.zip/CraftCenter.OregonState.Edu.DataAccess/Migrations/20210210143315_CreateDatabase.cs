﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CraftCenter.OregonState.Edu.DataAccess.Migrations
{
    public partial class CreateDatabase : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
