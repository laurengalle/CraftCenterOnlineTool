﻿using CraftCenter.OregonState.Edu.Services;
using CraftCenter.OregonState.Edu.Services.Requests;
using CraftCenter.OregonState.Edu.WebUI.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.WebUI.Controllers
{
    public class MembershipRegistration : Controller
    {
        private readonly IMembershipServices membershipServices;
        //private readonly ILogger<HomeController> _logger;

        //public MembershipRegistration(ILogger<HomeController> logger)
        //{
        //    _logger = logger;
        //}
        public MembershipRegistration(IMembershipServices membershipServices)
        {
            this.membershipServices = membershipServices;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CreateMembership(NewMembershipRequest request)
        {
            await membershipServices.CreateMembership(request);

            //todo:  navigate where you need to go
            return View("Index", request);

        }

        public IActionResult FAQ()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}