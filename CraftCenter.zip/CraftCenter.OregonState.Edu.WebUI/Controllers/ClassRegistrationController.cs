﻿using CraftCenter.OregonState.Edu.Services;
using CraftCenter.OregonState.Edu.WebUI.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.WebUI.Controllers
{
    [Route("classregistration")]
    public class ClassRegistrationController : Controller
    {
        private readonly IClassRegistrationService service;
        //private readonly ILogger<ClassRegistrationController> _logger;

        //public ClassRegistrationController(ILogger<ClassRegistrationController> logger)
        //{
        //    _logger = logger; // logs controller, could be used for unit testing
        //}

        public ClassRegistrationController(IClassRegistrationService service)
        {
            this.service = service;
        }

        [HttpGet("{category}")]
        public async Task<IActionResult> List(string category)
        {
            var response = await service.GetCoursesByCategory(category);
           
            //CourseListViewModel model = new CourseListViewModel();

            //switch (category)
            //{
            //    // Need a request to DB rather than hard coding right now, unit of work
            //    case "Ceramics":
            //    case "ceramics":
            //        model.CategoryName = "Ceramics";
            //        model.Courses = new List<CourseViewModel>() {
            //            new CourseViewModel() { CourseName = "chicken", CourseDate = DateTime.Now.ToString(), CourseDescription = "haha", CourseFee = "free", CourseId = 1 , CourseLength = "30 mins", CourseInstructor="Mr.X", CourseNumber = "cerv-12", CourseTime = "Any of clock" },
            //            new CourseViewModel() { CourseName = "duck", CourseDate = DateTime.Now.ToString(), CourseDescription = "heheh", CourseFee = "$100", CourseId = 2, CourseLength = "30 mins", CourseInstructor="Mr.X", CourseNumber = "cerv-12", CourseTime = "Any of clock" } };
            //        break;
            //    case "FiberArts":
            //    case "fiberarts":
            //        model.CategoryName = "Fiber Arts";
            //        model.Courses = new List<CourseViewModel>() {
            //            new CourseViewModel() { CourseName = "chicken", CourseDate = DateTime.Now.ToString(), CourseDescription = "haha", CourseFee = "free", CourseId = 1, CourseLength = "30 mins", CourseInstructor="Mr.X", CourseNumber = "cerv-12", CourseTime = "Any of clock" },
            //            new CourseViewModel() { CourseName = "duck", CourseDate = DateTime.Now.ToString(), CourseDescription = "heheh", CourseFee = "$100", CourseId = 2, CourseLength = "30 mins", CourseInstructor="Mr.X", CourseNumber = "cerv-12", CourseTime = "Any of clock" } };
            //        break;
            //    default:
            //        return NotFound(); // 404 page
            //}

            return View(response);
        }

        [HttpGet("courses/{courseId}")]
        public async Task<IActionResult> Schedule(int courseId)
        {
            var response = await service.GetSchedule(courseId);
            //CourseScheduleViewModel model = new CourseScheduleViewModel();

            //switch (category)
            //{
            //    case "Ceramics":
            //    case "ceramics":
            //        model.CourseName = "Ceramics";
            //        if(cid == 1)
            //        {
            //            model.Sections = new List<SectionClass>() { 
            //                new SectionClass() { Type="cool type", Time="this time", Instructor = "doctor kenne", SeatsFilled = "100/120", Status = "register" },
            //                new SectionClass() { Type="bad type", Time="that time", Instructor = "doctor tenne", SeatsFilled = "7/100", Status = "waitlist" } };
            //        }
            //        if (cid == 2)
            //        {
            //            model.Sections = new List<SectionClass>() {
            //                new SectionClass() { Type="cfdsf", Time="this time", Instructor = "doctor kenne", SeatsFilled = "100/120", Status = "register" },
            //                new SectionClass() { Type="sdfds", Time="that time", Instructor = "doctor tenne", SeatsFilled = "7/100", Status = "waitlist" } };
            //        }
            //        break;
            //    case "FiberArts":
            //    case "fiberarts":
            //        model.CourseName = "Fiber Arts";
            //        if (cid == 1)
            //        {
            //            model.Sections = new List<SectionClass>() {
            //                new SectionClass() { Type="cool type", Time="this time", Instructor = "doctor kenne", SeatsFilled = "100/120", Status = "register" },
            //                new SectionClass() { Type="bad type", Time="that time", Instructor = "doctor tenne", SeatsFilled = "7/100", Status = "waitlist" } };
            //        }
            //        if (cid == 2)
            //        {
            //            model.Sections = new List<SectionClass>() {
            //                new SectionClass() { Type="cfdsf", Time="this time", Instructor = "doctor kenne", SeatsFilled = "100/120", Status = "register" },
            //                new SectionClass() { Type="sdfds", Time="that time", Instructor = "doctor tenne", SeatsFilled = "7/100", Status = "waitlist" } };
            //        }
            //        break;
            //    default:
            //        break;
            //}
            return View(response);
        }

        [HttpGet]
        public async Task<IActionResult> GetCategories()
        {
            //var arr = new List<string>() { "Ceramics", "Fiber Arts", "Glass", "Jewelry", "Paper Arts", "Photography", "Woodworking" };
            
            var result = await service.GetAllCourseCategories();
            
            return View(result);
        }

        //public IActionResult Ceramics()
        //{
        //    var ceramicsCourseList = new List<CourseViewModel>();

        //    var ceramicsCourseOne = new CourseViewModel();
        //    ceramicsCourseOne.CourseId = 1;
        //    ceramicsCourseOne.CourseName = "Ceramics Orientation (Required Prior to Studio Use)";
        //    ceramicsCourseOne.CourseFee = "Free";
        //    ceramicsCourseOne.CourseLength = "30 mins";
        //    ceramicsCourseOne.CourseInstructor = "Spongebird";
        //    ceramicsCourseOne.CourseNumber = "CER-0";
        //    ceramicsCourseOne.CourseDescription = "Coll studfds";
        //    ceramicsCourseOne.CourseDate = "Tyesday";
        //    ceramicsCourseOne.CourseTime = "Never o'clock";

        //    ceramicsCourseList.Add(ceramicsCourseOne);

        //    return View(ceramicsCourseList);
        //}

        //public IActionResult FiberArts()
        //{
        //    var fiberartsCourseList = new List<CourseViewModel>();

        //    var fiberartsCourseOne = new CourseViewModel();
        //    fiberartsCourseOne.CourseId = 1;
        //    fiberartsCourseOne.CourseName = "Fiber Arts Orientation (Required Prior to Studio Use)";
        //    fiberartsCourseOne.CourseFee = "Free";
        //    fiberartsCourseOne.CourseLength = "30 mins";
        //    fiberartsCourseOne.CourseInstructor = "Spongebird";
        //    fiberartsCourseOne.CourseNumber = "CER-0";
        //    fiberartsCourseOne.CourseDescription = "Coll studfds";
        //    fiberartsCourseOne.CourseDate = "Tyesday";
        //    fiberartsCourseOne.CourseTime = "Never o'clock";

        //    fiberartsCourseList.Add(fiberartsCourseOne);

        //    return View(fiberartsCourseList);
        //}

        //public IActionResult Glass()
        //{
        //    return View();
        //}

        //public IActionResult Jewelry()
        //{
        //    return View();
        //}

        //public IActionResult PaperArts()
        //{
        //    return View();
        //}

        //public IActionResult Photography()
        //{
        //    return View();
        //}

        //public IActionResult Woodworking()
        //{
        //    return View();
        //}

        [HttpGet("error")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
