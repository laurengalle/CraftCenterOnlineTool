﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CraftCenter.OregonState.Edu.WebUI.Models
{
    public class CourseViewModel
    {
        public int CourseId { get; set; }
        
        public string CourseName { get; set; }

        public string CourseFee { get; set; }
        
        public string CourseLength { get; set; }

        public string CourseNumber { get; set; }

        public string CourseInstructor { get; set; }

        public string CourseDescription { get; set; }

        public string CourseDate { get; set; }

        public string CourseTime { get; set; }

        public IEnumerable<CourseScheduleViewModel> Schedule { get; set; }
    }
}
