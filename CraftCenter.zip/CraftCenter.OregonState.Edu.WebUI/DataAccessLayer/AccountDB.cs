﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using CraftCenter.OregonState.Edu.WebUI.SQLHelper;
using CraftCenter.OregonState.Edu.WebUI.Models;

namespace CraftCenter.OregonState.Edu.WebUI.DataAccessLayer
{
    public class AccountDB
    {
        ///*        public AccountDB(IConfiguration configuration)
        //        {
        //            Configuration = configuration;
        //        }

        //        public IConfiguration Configuration { get; }*/
        //string DataConnection = "Data Source=LAPTOP-BSEN8RAT;Initial Catalog=MVC-CraftCenter;Integrated Security=True;Connect Timeout=60;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        //public DataTable UserLogin(UserModel um)
        //{
        //    var parameters = new SqlParameter[]
        //   {
        //        new SqlParameter() {ParameterName = "@in_Name", Value = um.Name},
        //        new SqlParameter() {ParameterName = "@in_UID", Value = um.UID},
        //        new SqlParameter() {ParameterName = "@in_Email", Value = um.EmailAddress},
        //        new SqlParameter() {ParameterName = "@in_Issuer", Value = um.Issuer},
        //        new SqlParameter() {ParameterName = "@in_UserRole", Value = um.UserRole}
        //   };

        //    var datatable = SQLHelper.SQLHelper.GetDataTableFromSP(DataConnection, "Sp_InsertData", parameters);

        //    if (datatable != null && datatable.Rows.Count > 0)
        //    {
        //        return datatable;
        //    }
        //    return null;
        //}

    }
}
